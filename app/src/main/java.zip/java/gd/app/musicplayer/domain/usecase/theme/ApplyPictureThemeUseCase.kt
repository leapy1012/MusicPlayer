package gd.app.musicplayer.domain.usecase.theme

import android.content.Context
import gd.app.musicplayer.data.repository.ThemeRepo
import javax.inject.Inject

class ApplyPictureThemeUseCase @Inject constructor(
    private val themeRepo: ThemeRepo
) {
    suspend operator fun invoke(context: Context, imageName: String, overlayColor: Int, blur: Int) =
        themeRepo.applyPictureTheme(imageName, overlayColor, blur)
}
